import java.util.Scanner;
class Login extends Authenticator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Login or IIN:");
        Login login= new Login();
        login.setLogin("Shadow");
        String login_iin  = sc.next();

        if (login_iin.equals("050322550990") || login_iin.equals(login.getLogin())){
            System.out.println("Welcome!!!");

        }
        else{
            System.out.println("Incorrrect");
            System.exit(0);
        }
        System.out.println("Password:");
        login.setPassword("qwerty1234");
        String checkpassword1 = sc.next();
        if (checkpassword1.equals(login.getPassword())) {
            System.out.println("Please enter the text below");
            Captcha captcha = new Captcha();
        } else {
            System.out.println("You have 2 more attempts left");
            String checkpassword2 = sc.next();
            if (checkpassword2.equals(login.getPassword())) {
                System.out.println("Please enter the text below");
                Captcha captcha = new Captcha();
            } else {
                System.out.println("You have 1 more attempts left");
                String checkpassword3 = sc.next();
                if (checkpassword3.equals(login.getPassword())) {
                    System.out.println("Please enter the text below");
                    Captcha captcha = new Captcha();
                } else {
                    System.out.println("Access denied");
                }
            }
        }
    }
}




